<div class='bigLogo'><img src="logo.png" alt="Earth Hour"></div>
<h1><?php echo l('body_title') ?></h1>
<hr>
<p><?php echo l('body_text') ?></p>
<h3><?php echo l('body_about_title') ?></h3>
<p><?php echo l('body_about') ?></p>
<!-- <h3><?php echo l('body_partners_title') ?></h3> -->
<img src="eso.jpg" at="Environment Society of Oman" class="partner main-partner">
<img src="wwf.png" alt="wwf" class="partner">
<img src="earth_hour.jpg" at="Earth Hour" class="partner">