<?php
namespace PFBC\View;

class Search extends Inline {
	protected $class = "form-search";
}	
