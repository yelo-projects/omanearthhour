<?php
namespace PFBC\Element;

class DateTimeLocal extends Textbox {
	protected $_attributes = array("type" => "datetime-local");
}
