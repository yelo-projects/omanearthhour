<?php
namespace PFBC\Element;

class Time extends Textbox {
	protected $_attributes = array("type" => "time");
}
