<?php
namespace PFBC\Element;

class Range extends Textbox {
	protected $_attributes = array("type" => "range");
}
