<?php
namespace PFBC\Element;

class File extends \PFBC\Element {
	protected $_attributes = array("type" => "file");
}
