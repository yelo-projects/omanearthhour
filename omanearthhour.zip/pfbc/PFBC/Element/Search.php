<?php
namespace PFBC\Element;

class Search extends Textbox {
	protected $_attributes = array(
		"type" => "search",
		"class" => "search-query"
	);
}
